package integracao.rest;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
